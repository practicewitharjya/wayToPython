class Post:
    pass